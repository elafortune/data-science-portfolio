import numpy as np
import factorgraph_functions as fg

# Define Model1

# variables true and false
t=0
f=1

# DEFINE STRUCTURE FOR THE NODES WITH 8 NODES
node = [ fg.structtype() for i in range(8)]

# VARIABLE NODES
# DEFINE NODE 0
node[0].name='S'                        # fill in name
node[0].type='variable'                 # fill in values
node[0].values=np.array([t,f])          # assumed values
# DEFINE NODE 1
node[1].name='B'                        # fill in name
node[1].type='variable'                 # fill in values
node[1].values=np.array([t,f])          # assumed values
# DEFINE NODE 2
node[2].name='L'                        # fill in name
node[2].type='variable'                 # fill in values
node[2].values=np.array([t,f])          # assumed values
# DEFINE NODE 3
node[3].name='X'                        # fill in name
node[3].type='variable'                 # fill in values
node[3].values=np.array([t,f])          # assumed values

# FUNCTION NODES
# DEFINE NODE 4
node[4].name='p(S)'                     # fill in name
node[4].type='function'                 # fill in type
node[4].CPT=np.array([0.2, 0.8])        # conditional probability table
# DEFINE NODE 5
node[5].name='p(B|S)'                   # fill in name
node[5].type='function'                 # fill in type
node[5].CPT=np.array([[0.25, 0.75],
                      [0.05, 0.95]])    # conditional probability table
# DEFINE NODE 6
node[6].name='p(L|S)'                   # fill in name
node[6].type='function'                 # fill in type
node[6].CPT=np.array([[0.003, 0.997],
                      [0.00005, 0.99995]])    # conditional probability table
# DEFINE NODE 7
node[7].name='p(X|L)'                   # fill in name
node[7].type='function'                 # fill in type
node[7].CPT=np.array([[0.6, 0.4],
                      [0.02, 0.98]])    # conditional probability table

# DEFINE ADJACENCY MATRIX OF THE FACTOR GRAPH
B=np.array([[1, 1, 1, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 1],
            [0, 0, 0, 1]])
Adj=np.block([[np.zeros((4,4)),B],
              [B.T,np.zeros((4,4))]])

# NUMBER OF NODES IN THE FACTOR GRAPH
N=np.size(Adj,0)

# INIT MESSAGES
Message=fg.InitMessages(N,node,Adj)
# print leaf node messages after initialization
Message[1][5].send=[1,0]
print(Message[1][5].send)
print(Message[3][7].send)
print(Message[4][0].send)
print(Message[6][2].send)

# SUM-PRODUCT ALGORITHM ON A TREE IS EXACT
[Message,Marginal]=fg.SumProductAlgorithm(N,node,Adj,Message)

# DISPLAY PRIOR NODE PROBABILITIES
print('Marginals obtained from sum-product algorithm');
for X in range(N):
    if node[X].type=='variable':
        print('P(', node[X].name, ') = ', Marginal[X].pmf)
        
        
width=0.85
ind=()
for X in range(N):
  if node[X].type=='variable':
    ind=ind+(X,)
nodeNames=[]
for X in range(N):
  if node[X].type=='variable':
    nodeNames.append(node[X].name)
    print(ind)
    print(nodeNames)
blueBars=()
yellowBars=()
for X in range(N):
  if node[X].type=='variable':
    blueBars=blueBars+(Marginal[X].pmf[t],)
    yellowBars=yellowBars+(Marginal[X].pmf[f],)
p1=plt.bar(ind,blueBars,width,color='blue')
p2=plt.bar(ind,yellowBars,width,color='yellow',bottom=blueBars)
plt.ylabel('Probability')
plt.title('Marginals')
plt.xticks(ind,nodeNames)        


