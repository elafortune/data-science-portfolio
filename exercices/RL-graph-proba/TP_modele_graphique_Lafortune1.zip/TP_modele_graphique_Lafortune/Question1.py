# -*- coding: utf-8 -*-
import numpy as np

#####################################################################
#
#  define an dummy class to build C-like structures
#
# (python dictionary has keys of type int, float, character only -
#  numpy structured array can only have fixed-size np.arrays as fields)
#
####################################################################
class structtype():
    pass

#####################################################################
#
# Sum-product algorithm initialization
#
# Assumption: size(node[i].CPT,0)=1 for all leaf nodes
#
# Input arguments:
# - N: number of nodes in the factor graph
# - node[N]: node structure
# - Adj[NxN]: adjacency matrix of the factor graph
#
# Output arguments:
# - Message[NxN]: array of matrices representing the messages after
#                 initialization
#
#####################################################################
def InitMessages(N,node,Adj):
   # CREATE AN ARRAY [NxN] EMPTY MATRICES REPRESENTING THE MESSAGES
   Message = [[structtype() for j in range(N)] for i in range(N)]
   for i in range(N):
      for j in range(N):
         Message[i][j].send=[]

   # scan all nodes in the factor graph
   for X in range(N):
      # find all neighboring nodes of X
      neighbors=np.where(Adj[X,:]>0)[0]
      # init only leaf node messages
      if len(neighbors)==1:
         # init leaf variable nodes messages
         if node[X].type=='variable':
            # send  all one message to neighboring function nodes
            for n in range(len(neighbors)):
               Message[X][neighbors[n]].send=np.ones((node[X].values).size)
         # init leaf function nodes messages
         else:
            # send function node to neighboring variable nodes
            for n in range(len(neighbors)):
               Message[X][neighbors[n]].send=node[X].CPT

   return Message

#####################################################################
#
# Sum-product algorithm with flooding schedule:
# update until each edge in factor graph has been traversed in each direction
#
# Input arguments:
# - N: number of nodes in the factor graph
# - node[N]: node structure
# - Adj[NxN]: adjacency matrix of the factor graph
# - Message[NxN]: array of empty matrices representing the messages
#
# Output arguments:
# - Message[NxN]: array of matrices representing the messages after
#                 the sum-product update
# - Marginal[number of variables nodes]: array of matrices representing the marginals
#
#####################################################################
def SumProductAlgorithm(N,node,Adj,Message):
   # scan all nodes while a message to a neighbor is empty
   loop=True
   while(loop):
      # scan all nodes in the factor graph
      for X in range(N):
         # find all neighboring nodes of X
         neighbors=np.where(Adj[X,:]>0)[0]
         # compute a message towards all neighbors of X - if possible
         for n in range(len(neighbors)):
            # collect the set of neighbors\neighbor[n]
            delta=np.setdiff1d(neighbors,neighbors[n])
            # test if the message towards neighbors[n] is empty and computable
            computable=True
            for m in range(len(delta)):
               if len(Message[delta[m]][X].send)==0:
                  computable=False
            if len(Message[X][neighbors[n]].send)==0 and computable==True:
               # update variable to function node messages
               if node[X].type=='variable':
                  # compute the product of all incoming messages from delta
                  Message[X][neighbors[n]].send=np.ones((node[X].values).size)
                  for m in range(len(delta)):
                     Message[X][neighbors[n]].send=\
                        Message[X][neighbors[n]].send*Message[delta[m]][X].send
               # update function to variable node messages
               elif node[X].type=='function':
                  # - compute function node x product of all incoming
                  # messages from delta conserving the order of the variables
                  w=1
                  for m in range(len(delta)):
                     w=np.kron(Message[delta[m]][X].send,w)
                  # - and marginalize out all variables except neighbors[n]
                  # for all values assumed by variable node neighbors[n]
                  Message[X][neighbors[n]].send=\
                     np.zeros((node[neighbors[n]].values).size)
                  for v in range(len(node[neighbors[n]].values)):
                     # shift the dimension corresponding to neighbors[n]
                     # towards first dimension
                     I=np.where(neighbors[n]==neighbors)[0]
                     # shift the I-th dimension to the 0-th position and keep the ordering of all other dimensions
                     prob=np.rollaxis(node[X].CPT,I.item())
                     # cyclically shift the dimensions of CPT by I positions to the left - equivalent to shiftdim in Matlab
                     #prob=np.moveaxis(node[X].CPT,np.arange(node[X].CPT.ndim), np.roll(np.arange(node[X].CPT.ndim),I))
                     Message[X][neighbors[n]].send[v]=\
                         np.sum(prob[v,:].flatten(order='F')*w)

      # stopping rule: check if at least one message in the array is missing
      loop=False
      for i in range(N):
         for j in range(N):
            if Adj[i,j]==1:
               if len(Message[i][j].send)==0:
                  loop=True
      # end of while

   # Termination: as soon as each edge in factor graph has been traversed in each direction
   # Collect set of variable nodes
   variable_nodes=[]
   for n in range(N):
      if node[n].type=='variable':
         variable_nodes=np.append(variable_nodes,n)

   # Compute marginal for each variable node
   Marginal= [ structtype() for i in range(len(variable_nodes))]
   for X in range(len(variable_nodes)):
      # find all neighboring nodes of X
      neighbors=np.where(Adj[X,:]>0)[0]
      # compute marginal of X
      Marginal[X].pmf=np.ones((node[X].values).size)
      for m in range(len(neighbors)):
         Marginal[X].pmf=Marginal[X].pmf*Message[neighbors[m]][X].send
      # normalize marginal of X to probability mass function
      Marginal[X].pmf=Marginal[X].pmf/np.sum(Marginal[X].pmf)

   return Message,Marginal



