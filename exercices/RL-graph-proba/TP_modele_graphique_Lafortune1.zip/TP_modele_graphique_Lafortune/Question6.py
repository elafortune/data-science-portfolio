# -*- coding: utf-8 -*-
###########################################################################
#
#   Model the Lung Cancer Diagnosis Problem, Ignoring Fatigue Feature
# - Compute Prior feature probabilities using the sum-product algorithm
#
###########################################################################
import numpy as np
import factorgraph_functions as fg
import matplotlib.pyplot as plt
# Define Model1

# variables true and false
t=0
f=1

# DEFINE STRUCTURE FOR THE NODES WITH 8 NODES
node = [ fg.structtype() for i in range(8)]

# VARIABLE NODES
# DEFINE NODE 0
node[0].name='S'                        # fill in name
node[0].type='variable'                 # fill in values
node[0].values=np.array([t,f])          # assumed values
# DEFINE NODE 1
node[1].name='B'                        # fill in name
node[1].type='variable'                 # fill in values
node[1].values=np.array([t,f])          # assumed values
# DEFINE NODE 2
node[2].name='L'                        # fill in name
node[2].type='variable'                 # fill in values
node[2].values=np.array([t,f])          # assumed values
# DEFINE NODE 3
node[3].name='X'                        # fill in name
node[3].type='variable'                 # fill in values
node[3].values=np.array([t,f])          # assumed values

# FUNCTION NODES
# DEFINE NODE 4
node[4].name='F'                     # fill in name
node[4].type='variable'                 # fill in values
node[4].CPT=np.array([t,f])        # assumed values

# DEFINE NODE 5
node[5].name='p(S)'                   # fill in name
node[5].type='function'                 # fill in type
node[5].CPT=np.array([[0.2, 0.8]])    # conditional probability table

# DEFINE NODE 6
node[6].name='p(B|S)'                   # fill in name
node[6].type='function'                 # fill in type
node[6].CPT=np.array([[0.25, 0.75],
                      [0.05, 0.95]])    # conditional probability table
# DEFINE NODE 7
node[7].name='p(L|S)'                   # fill in name
node[7].type='function'                 # fill in type
node[7].CPT=np.array([[0.003, 0.997],
                      [0.00005, 0.99995]])    # conditional probability table

# DEFINE NODE 8
node[8].name='p(X|L)'                   # fill in name
node[8].type='function'                 # fill in type
node[8].CPT=np.array([[0.6, 0.4],
                      [0.02, 0.98]])    # conditional probability table

# DEFINE NODE 9
node[9].name='p(F|B,L)'                   # fill in name
node[9].type='function'                 # fill in type
node[9]
node[9].CPT=np.array([[0.75, 0.25],
                      [0.02, 0.98]])    # conditional probability table
# DEFINE ADJACENCY MATRIX OF THE FACTOR GRAPH
B=np.array([[1, 1, 1, 0, 0],
            [0, 1, 0, 0, 1],
            [0, 0, 1, 1, 1],
            [0, 0, 0, 1, 0]
            [0, 0, 0, 0, 1]])            
Adj=np.block([[np.zeros((5,5)),B],
              [B.T,np.zeros((5,5))]])

# NUMBER OF NODES IN THE FACTOR GRAPH
N=np.size(Adj,0)

# INIT MESSAGES
Message=fg.InitMessages(N,node,Adj)
# print leaf node messages after initialization
print(Message[1][5].send)
print(Message[3][7].send)
print(Message[4][0].send)
print(Message[7][2].send)
# SUM-PRODUCT ALGORITHM ON A TREE IS EXACT
[Message,Marginal]=fg.SumProductAlgorithm(N,node,Adj,Message)

# DISPLAY PRIOR NODE PROBABILITIES
print('Marginals obtained from sum-product algorithm');
for X in range(N):
    if node[X].type=='variable':
        print('P(', node[X].name, ') = ', Marginal[X].pmf)
    
#QUESTION 2

#representer les lois marginales par un diagramme en bar en utilisant matplotlib

#largeur des barres 
width=0.85
#tuple contenant les indices des noeuds de variable
ind=()
for X in range(N):
    if node[X].type=='variable':
        ind=ind+(X,)
#liste contenant le nom des noeuds de variable
nodeNames=[]
for X in range(N):
    if node[X].type=='variable':
        nodeNames.append(node[X].name)
#creation de barres bleues pour la proba de valoir t
blueBars=()  
#creation de barres jaunes pour la proba de valoir f
yellowBars=()
for X in range(N):
    if node[X].type=='variable':
        blueBars=blueBars+(Marginal[X].pmf[t],)
        yellowBars=yellowBars+(Marginal[X].pmf[f],)

#tracer les barres bleues
p1=plt.bar(ind,blueBars,width,None)


#tracer les barres jaunes
p2=plt.bar(ind,yellowBars,width,None)

plt.legend( (p1[0],p2[0]), ('t', 'f'))
#Visualisation
plt.show()



#QUESTION 3
#Calcul des lois marginales par l'approche directe
#tuple contenant la dimension du tableau


dim=()
for X in range(N):
    if node[X].type=='variable':
        dim=dim+(len(node[1].values),)
 #créer le tableau pour la loi jointe de toutes les variables
LoiJointe=np.zeros(dim)
#remplir le tableau pour la loi jointe de toutes les variables
for Svalue in range(t,f+1):
    for Bvalue in range(t,f+1):
        for Lvalue in range(t,f+1):
            for Xvalue in range(t,f+1):
                LoiJointe[Svalue,Bvalue,Lvalue,Xvalue]=node[4].CPT[Svalue]*node[5].CPT[Svalue,Bvalue]*node[6].CPT[Svalue,Lvalue].node[7].CPT[Lvalue,Xvalue]


#calcul des lois marginales
ExactMarginal= [ fg.structtype() for i in range(len(variable_nodes))]
for X in range(N):
    if node[X].type=='variable':
        #ramener l'axe sur lequel on ne somme pas en position 0
        ExactMarginal[X].pmf=np.sum(LoiJointe,axis=(1,2,3))
        #normalisation de loi marginale
        ExactMarginal[X].pmf=ExactMarginal[X].pmf/np.sum(ExactMarginal[X].pmf)



#DISPLAY EXACT PRIOR NODE PROBABILITIES
print('Marginals obtained from brute force')
for X in range(N):
    if node[X].type=='variable':
        print('P(', node[X].name,') = ',ExactMarginal[X].pmf)