# -*- coding: utf-8 -*-
###########################################################################
#
# Simulate database recording for Npatients=1e7 patients:
# - Smoking history (S)    
# - presence of Bronchitis (B)    
# - presence of Lung Cancer (L)    
# - Lesion in X-ray (X)    
# - presence of Fatigue (F)
# according to the probabilistic model including the fatigue feature
#
###########################################################################
import numpy as np
# importing module (that is not in a package) from parent directory
import os,sys,inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir) 
import factorgraph_functions as fg
# importing module my_functions
import my_functions as my

################################################################################
#
#  Number of patients
#
################################################################################
Npatients=10000000

################################################################################
#
# PARAMETERS OF PROBABILISTIC MODEL 
# INCUDING FATIGUE FEATURE (F DEPENDENT ON B,L)
#
################################################################################
# NUMBER OF NODES IN THE FACTOR GRAPH
N=10;

# variables true and false
t=0
f=1

# DEFINE STRUCTURE FOR THE NODES WITH 8 NODES
node = [ fg.structtype() for i in range(N)]

# VARIABLE NODES
# DEFINE NODE 0
node[0].name='S'                        # fill in name
node[0].type='variable'                 # fill in values
node[0].values=np.array([t,f])          # assumed values
# DEFINE NODE 1
node[1].name='B'                        # fill in name
node[1].type='variable'                 # fill in values
node[1].values=np.array([t,f])          # assumed values
# DEFINE NODE 2
node[2].name='L'                        # fill in name
node[2].type='variable'                 # fill in values
node[2].values=np.array([t,f])          # assumed values
# DEFINE NODE 3
node[3].name='X'                        # fill in name
node[3].type='variable'                 # fill in values
node[3].values=np.array([t,f])          # assumed values
# DEFINE NODE 4
node[4].name='F'                        # fill in name
node[4].type='variable'                 # fill in values
node[4].values=np.array([t,f])          # assumed values

# FUNCTION NODES
# DEFINE NODE 5
node[5].name='p(S)'                     # fill in name
node[5].type='function'                 # fill in type
node[5].CPT=np.array([0.2, 0.8])        # conditional probability table
# DEFINE NODE 6
node[6].name='p(B|S)'                   # fill in name
node[6].type='function'                 # fill in type
node[6].CPT=np.array([[0.25, 0.75],
                      [0.05, 0.95]])    # conditional probability table
# DEFINE NODE 7
node[7].name='p(L|S)'                   # fill in name
node[7].type='function'                 # fill in type
node[7].CPT=np.array([[0.003, 0.997],
                      [0.00005, 0.99995]])    # conditional probability table
# DEFINE NODE 8
node[8].name='p(X|L)'                   # fill in name
node[8].type='function'                 # fill in type
node[8].CPT=np.array([[0.6, 0.4],
                      [0.02, 0.98]])    # conditional probability table
# DEFINE NODE 9
node[9].name='p(F|B,L)'                 # fill in name
node[9].type='function'                 # fill in type
node[9].CPT=np.zeros((2,2,2))             # conditional probability table
node[9].CPT[:,:,t]=np.array([[0.75, 0.1],
                             [0.5, 0.05]])
node[9].CPT[:,:,f]=1-node[9].CPT[:,:,t]

################################################################################
#
# SIMULATE Npatients SAMPLES FROM THE PROBABILISTIC MODEL 
#
################################################################################
patients = [ fg.structtype() for n in range(Npatients)]
for n in range(Npatients):
    # simulate feature S for the current patient  
    patients[n].S=my.discrete(node[0].values,node[5].CPT)
    # simulate feature B|S for the current patient
    patients[n].B=my.discrete(node[1].values,node[6].CPT[patients[n].S,:])
    # simulate feature L|S for the current patient
    patients[n].L=my.discrete(node[2].values,node[7].CPT[patients[n].S,:])
    # simulate feature X|L for the current patient
    patients[n].X=my.discrete(node[3].values,node[8].CPT[patients[n].L,:])
    # simulate feature F|B,L for the current patient
    patients[n].F=my.discrete(node[4].values,node[9].CPT[patients[n].B,patients[n].L,:])        

################################################################################
#
#   Output file
#
################################################################################
filename_out='Patients.txt'
# write header to Output file
my_array=['Lung Cancer Diagnosis Patient Database \n']
np.savetxt(filename_out, my_array, fmt='%s')
f=open(filename_out,'a')
my_array=['patient number    Smoking history (S)    presence of Bronchitis (B)    presence of Lung Cancer (L)    Lesion in X-ray (X)    presence of Fatigue (F) ']
np.savetxt(f, my_array, fmt='%s')
f.write("\n ")
# write features of each patient to Output file
for n in range(Npatients):
    my_array=np.array([n,patients[n].S,patients[n].B,patients[n].L,patients[n].X,patients[n].F])
    np.savetxt(f, np.column_stack(my_array), fmt='%8d                        %d                        %d                         %d                          %d                               %d')
    f.write(" ")
f.close()
